package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.myapplication.SearchActivity;

import java.util.ArrayList;

public class HomeFragment extends Fragment {
TextView tvSearch;

    @Nullable
    ViewPager viewPager;
    int images[] = {R.drawable.pancake, R.drawable.ls,
            R.drawable.jassi, R.drawable.mocha,R.drawable.redbistro,};

    GridView gridView;

    String strLang[] = {"Food Trucks", "Cafes", "Buffets", "Late Night", "Street Food", "Tiffin Services",};
    int imgLang[] = {R.drawable.foodtruck, R.drawable.cafes
            , R.drawable.buffets, R.drawable.latefood,
            R.drawable.streetfood, R.drawable.tiffin};

    ArrayList<DataModel> dataModelArrayList;
    private Object ViewpagerCustom;

    public HomeFragment() {
          ViewpagerCustom = new ViewpagerCustom(getActivity(), images);
    }


    @SuppressLint("WrongViewCast")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View rootview = inflater.inflate(R.layout.fragment_home, container, false);


        gridView = (GridView) rootview.findViewById(R.id.gridview);
        tvSearch = (TextView) rootview.findViewById(R.id.tv_search);
        tvSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getContext(), SearchActivity.class);
                getContext().startActivity(i);
            }
        });

        dataModelArrayList = new ArrayList<DataModel>();
        for (int i = 0; i < strLang.length; i++) {

            DataModel dataModel = new DataModel(strLang[i], imgLang[i]);
            dataModelArrayList.add(dataModel);
        }


        FtGridAdapter ftGridAdapter = new FtGridAdapter(getActivity(), dataModelArrayList);
        gridView.setAdapter(ftGridAdapter);

        viewPager = (ViewPager) rootview.findViewById(R.id.viewpager);
        viewPager.setAdapter((PagerAdapter) ViewpagerCustom);

        return rootview;
    }



    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        getActivity().setTitle("Home");
    }


}

