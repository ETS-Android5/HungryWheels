package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;


public class BusinessOwnerActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    RadioGroup service,owner_manager_group,opening_status,payment;
    RadioButton seating,noseating,owner_manager,not_owner_manager,already_open,opening_soon,card_cash,cash_only,radioButton,radioButton1,radioButton2,radioButton3;
    int radioButtonId,radioButtonId1,radioButtonId2,radioButtonId3;
    private String rdbtn,rdbtn1,rdbtn2,rdbtn3,restaurantName,cityName,restaurantNo,address1,tag,fromTime,toTime;
    CheckBox indoor,outdoor,monday,tuesday,wednesday,thursday,friday,saturday,sunday;
    LinearLayout check_layout;
    EditText restaurant_name,city_name,restaurant_no,address;
    Spinner tags,from_time,to_time;
    Button add_time,submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_business_owner);
        Toolbar toolbar1 = (Toolbar) findViewById(R.id.toolbar1);
        setSupportActionBar(toolbar1);
        toolbar1.setTitle("Hungry Wheels");
        service = findViewById(R.id.service);
        seating = findViewById(R.id.seating);
        noseating = findViewById(R.id.noseating);
        indoor = findViewById(R.id.indoor_seating);
        outdoor = findViewById(R.id.outdoor_seating);
        check_layout = findViewById(R.id.checkbox_layout);
        monday = findViewById(R.id.monday);
        tuesday = findViewById(R.id.tuesday);
        wednesday = findViewById(R.id.wednesday);
        thursday= findViewById(R.id.thursday);
        friday= findViewById(R.id.friday);
        saturday = findViewById(R.id.saturday);
        sunday = findViewById(R.id.sunday);
        restaurant_name = findViewById(R.id.restaurant_name);
        city_name = findViewById(R.id.city_name);
        restaurant_no = findViewById(R.id.restaurant_no);
        address = findViewById(R.id.address);
        tags = findViewById(R.id.tags);
        from_time = findViewById(R.id.from_time);
        to_time = findViewById(R.id.to_time);
        add_time = findViewById(R.id.add_time);
        owner_manager_group = findViewById(R.id.owner_manager_group);
        opening_soon = findViewById(R.id.opening_soon);
        opening_status = findViewById(R.id.opening_status);
        payment = findViewById(R.id.payment);
        owner_manager = findViewById(R.id.owner_manager);
        not_owner_manager = findViewById(R.id.not_owner_manager);
        already_open = findViewById(R.id.already_open);
        card_cash = findViewById(R.id.card_cash);
        cash_only = findViewById(R.id.cash_only);
        submit = findViewById(R.id.submit);

        restaurantName = restaurant_name.getText().toString();
        cityName = city_name.getText().toString();
        restaurantNo = restaurant_no.getText().toString();
        address1 = address.getText().toString();

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validate()){
                    Toast.makeText(BusinessOwnerActivity.this, "Submit successful", Toast.LENGTH_SHORT).show();
                }
            }
        });

        final ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(BusinessOwnerActivity.this,android.R.layout.simple_list_item_1,getResources().getStringArray(R.array.tags));
        adapter1.setDropDownViewResource(android.R.layout.simple_list_item_1);
        tags.setAdapter(adapter1);

        tags.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (adapterView.getItemAtPosition(i).toString().equalsIgnoreCase("")){
                    tag = "";
                } else {
                    tag = (String) adapterView.getItemAtPosition(i);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        DrawerLayout drawer1 = (DrawerLayout) findViewById(R.id.drawer_layout1);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer1, toolbar1, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer1.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.bussiness_navigation);
        navigationView.setNavigationItemSelectedListener(this);

    }

    public void checked_item(View v){
        radioButtonId = service.getCheckedRadioButtonId();
        radioButton = findViewById(radioButtonId);
        rdbtn = radioButton.getText().toString();

        if (seating.isChecked()){
           check_layout.setVisibility(View.VISIBLE);
        } else{
            check_layout.setVisibility(View.GONE);
        }

        Toast.makeText(this, "Your choice is..."+rdbtn, Toast.LENGTH_SHORT).show();
    }

    public void checked_item1(View v){
        radioButtonId1 = owner_manager_group.getCheckedRadioButtonId();
        radioButton1 = findViewById(radioButtonId1);
        rdbtn1 = radioButton.getText().toString();

    }

    public void checked_item2(View v){
        radioButtonId2 = service.getCheckedRadioButtonId();
        radioButton2 = findViewById(radioButtonId2);
        rdbtn2 = radioButton.getText().toString();
    }

    public void checked_item3(View v) {
        radioButtonId3 = service.getCheckedRadioButtonId();
        radioButton3 = findViewById(radioButtonId3);
        rdbtn3 = radioButton.getText().toString();
    }

    public boolean validate(){

        if (restaurantName.isEmpty()){
            restaurant_name.setError("Enter Restaurant Name");
            return false;
        } else if (cityName.isEmpty()){
            city_name.setError("Enter City Name");
            return false;
        } else if (restaurantNo.isEmpty()){
            restaurant_no.setError("Enter Restaurant No.");
            return false;
        } else if (!owner_manager.isChecked() && !not_owner_manager.isChecked()){
            Toast.makeText(this, "Please select a type", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!already_open.isChecked() && !opening_soon.isChecked()){
            Toast.makeText(this, "Please Select opening status", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!seating.isChecked() && !noseating.isChecked()){
            Toast.makeText(this, "Please select services", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!card_cash.isChecked() && !cash_only.isChecked()){
            Toast.makeText(this, "Please select Payment method", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            return true;
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int id = menuItem.getItemId();

        if (id == R.id.Business_home) {
            Toast.makeText(this, "Business Home Activity", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.Business_menu) {
            Toast.makeText(this, "Business Menu activity", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.Business_orders) {
            Toast.makeText(this, "Business Order activity", Toast.LENGTH_SHORT).show();
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
